var express = require('express');
var app = express();
var bodyParser=require('body-parser');

app.use(bodyParser.json()); //parsing stream data to readable format

app.post('/test', function (req, res) {
	var city = req.body.city
	var collage = req.body.collage
  res.send('city :'+city+ '  collage :'+collage);
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});