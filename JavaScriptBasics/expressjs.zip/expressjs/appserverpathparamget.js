var express = require('express');
var app = express();

app.get('/test/:city/:collage', function (req, res) {
	
	var city = req.params.city;
	var collage = req.params.collage
  res.send('city :'+city+ '  collage :'+collage);
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});

/*
localhost:3000/test/banglore/svuniversity
*/