var express = require('express');
var app = express();

app.get('/test', function (req, res) {
	var city = req.query.city;
	var collage = req.query.collage
  res.send('city :'+city+ '  collage :'+collage);
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});



/*
http://localhost:3000/test?city=banglore&collage=svuniversity
*/