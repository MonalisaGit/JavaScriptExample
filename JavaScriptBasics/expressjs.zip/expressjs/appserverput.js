var express = require('express');
var app = express();
var bodyParser=require('body-parser');

app.use(bodyParser.json());

app.put('/test/putmethod/:city', function (req, res) {
	console.log("request body data"+JSON.stringify(req.body));
  res.send(req.params.city);
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});